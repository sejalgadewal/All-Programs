module MathOperationMixin 
    def addition(a,b)
        a+b
    end
    def subtraction(a,b)
        a-b
    end
    def multiplication(a,b)
        a*b
    end
end

class Calculator
include MathOperationMixin
end

puts "Enter First Value :- "
a=gets.to_i

puts "Enter Second Value :- "
b=gets.to_i


add=Calculator.new.addition(a,b)
sub=Calculator.new.subtraction(a,b)
mul=Calculator.new.multiplication(a,b)

puts "Addition is :- #{add}"
puts "Subtraction is :- #{sub}"
puts "Multiplication is :- #{mul}"

